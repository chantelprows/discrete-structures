#ifndef SCHEME_H
#define SCHEME_H

#include <vector>
#include <iostream>

using namespace std;

class Scheme : public vector<string> {

public:

	//Scheme() {}

	
	//tostring

private:

};


#endif
