#ifndef TUPLE_H
#define TUPLE_H

#include <vector>
#include <iostream>

using namespace std;

class Tuple : public vector<string> {

public:

};

#endif
